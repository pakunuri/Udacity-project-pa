"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    "dev": {
        "username": "udagramakudev",
        "password": "$Udagram_2020",
        "database": "udagramakudev",
        "host": "udagramakudev.cu1hzbxc8icj.us-east-1.rds.amazonaws.com",
        "dialect": "postgres",
        "aws_region": "us-east-1",
        "aws_profile": "default",
        "aws_media_bucket": "udagramakudev"
    },
    "prod": {
        "username": "",
        "password": "",
        "database": "udagram_prod",
        "host": "",
        "dialect": "postgres"
    }
};
//# sourceMappingURL=config.js.map